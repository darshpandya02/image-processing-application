package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import controller.GUIController;
import model.ImageModel;

/**
 * The ImageView class displays images, buttons to perform functions on the said image and handles
 * user interactions. It implements the ImageViewInterface. It creates a JFrame to display the
 * image and buttons.
 */
public class ImageView implements ImageViewInterface {
  public final Appendable out;
  private final JFrame frame;
  private final JPanel imagePanel;
  private final JLabel[] imageLabels;
  private final JScrollPane[] scrollPanes;
  private final JButton[] buttons;
  private final JTextField textField;
  private final GUIController GUIcontroller;
  private final int[] param_levels = {0, 128, 255};
  public Readable in;
  private ImageModel model;
  private int param_compress;
  private int splitParam = 100;
  private boolean isNotSaved = false;
  private String stringInput = "";

  private boolean correctSplit = true;

  private boolean imageLoaded = false;
  private String splitCommand = "";
//  private JSlider slider;
//  private JLabel valueLabel;
//  private JLabel imageLabelSplit;

  /**
   * This is the constructor for the ImageView class used to display the image and handle user
   * interactions.
   *
   * @param in  readable input
   * @param out appendable output
   */
  public ImageView(Readable in, Appendable out) {
    this.in = in;
    this.out = out;
    this.frame = new JFrame("Image View");
    this.GUIcontroller = new GUIController(model);

    GUIcontroller.setView(this);
    JPanel buttonsPanel = new JPanel(new GridLayout(2, 9));
    buttons = new JButton[17];
    textField = new JTextField(15);
    for (int i = 0; i < 17; i++) {
      buttons[i] = new JButton();
      buttonsPanel.add(buttons[i]);
      final int buttonIndex = i;

      buttons[i].addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
          try {
            String input = handleButtonClick(buttonIndex);
            GUIcontroller.handleClick(input);
          } catch (IOException ex) {
            throw new RuntimeException(ex);
          } catch (Exception ex) {
            throw new RuntimeException(ex);
          }
        }
      });


      if (i == 12) {
        buttons[i].addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            showPopupTextFieldForCompress();
          }
        });
      }
//      } else if (i == 14) {
//        buttons[i].addActionListener(new ActionListener() {
//          @Override
//          public void actionPerformed(ActionEvent e) {
//            showPopupTextFieldForLevels();
//          }
//        });
//      }


    }
    for (int j = 0; j < 17; j++) {
      if (j == 4 || j == 5 || j == 6 || j == 7 || j == 8 || j == 9 || j == 13 || j == 14) {
        int finalI = j;
        buttons[j].addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            if (finalI == 14) {
              showPopupTextFieldForLevels();
            }
            try {
              int dialogResult = JOptionPane.showConfirmDialog(null,
                      "Do you want to view the split preview of the image",
                      "Confirmation", JOptionPane.YES_NO_OPTION);

              if (dialogResult == JOptionPane.YES_OPTION) {
                // Create a custom dialog
                JDialog splitDialog = new JDialog(frame, "Split Preview", true);
                splitDialog.setLayout(new BorderLayout());

                JPanel panel = new JPanel();
                JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
                slider.setMajorTickSpacing(10);
                slider.setMinorTickSpacing(1);
                slider.setPaintTicks(true);
                slider.setPaintLabels(true);

                JLabel valueLabel = new JLabel("Value: " + slider.getValue());
                JLabel imageLabelSplit = new JLabel();
                panel.setLayout(new FlowLayout());

                slider.addChangeListener(new ChangeListener() {
                  @Override
                  public void stateChanged(ChangeEvent e) {
                    valueLabel.setText("Value: " + slider.getValue());
                    try {
                      String input = handleButtonClick(finalI);
                      int[][][] previewImage = GUIcontroller.displayPreview(input,
                              slider.getValue());
                      ImageIcon imageIcon = createImageIcon(previewImage);
                      imageLabelSplit.setIcon(imageIcon);
                    } catch (Exception ex) {
                      throw new RuntimeException(ex);
                    }
                  }
                });

                panel.add(slider);
                panel.add(valueLabel);
                panel.add(imageLabelSplit);

                splitDialog.add(panel, BorderLayout.CENTER);

                // Add OK and Cancel buttons
                JButton okButton = new JButton("OK");
                JButton cancelButton = new JButton("Cancel");

                okButton.addActionListener(new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e) {
                    // Handle OK button action
                    int userInput = slider.getValue();
                    if (userInput >= 0 && userInput <= 100) {
                      splitParam = 100;
                      correctSplit = true;
                    } else {
                      correctSplit = false;
                      JOptionPane.showMessageDialog(null,
                              "Parameter for split must be an integer between 0 and 100.",
                              "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Close the dialog
                    splitDialog.dispose();
                  }
                });

                cancelButton.addActionListener(new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e) {
                    // Handle Cancel button action
                    correctSplit = true;
                    splitParam = 0;

                    // Close the dialog
                    splitDialog.dispose();
                  }
                });

                JPanel buttonPanel = new JPanel();
                buttonPanel.add(okButton);
                buttonPanel.add(cancelButton);
                splitDialog.add(buttonPanel, BorderLayout.SOUTH);

                splitDialog.setSize(800, 500);
                splitDialog.setLocationRelativeTo(frame);
                splitDialog.setVisible(true);
              } else {
                correctSplit = true;
                splitParam = 100;
              }
            } catch (Exception ex) {
              throw new RuntimeException(ex);
            }
          }
        });

      }
    }

    buttons[0].setText("Load an Image");
    buttons[1].setText("Red-Component");
    buttons[2].setText("Green-Component");
    buttons[3].setText("Blue-Component");
    buttons[4].setText("value-component");
    buttons[5].setText("intensity-component");
    buttons[6].setText("luma-component");
    buttons[7].setText("sepia");
    buttons[8].setText("blur");
    buttons[9].setText("sharpen");
    buttons[10].setText("Flip Horizontally");
    buttons[11].setText("Flip Vertically");
    buttons[12].setText("Compress");
    buttons[13].setText("color-correct");
    buttons[14].setText("levels-adjust");
    buttons[15].setText("Save Histogram");
    buttons[16].setText("Save the Image");

    frame.getContentPane().setLayout(new BorderLayout());
    frame.getContentPane().add(buttonsPanel, BorderLayout.NORTH);
    frame.getContentPane().add(textField);
    this.imagePanel = new JPanel();
    imagePanel.setLayout(new GridLayout(2, 2));
    this.imageLabels = new JLabel[4];
    this.scrollPanes = new JScrollPane[4];
    for (int i = 0; i < 4; i++) {
      imageLabels[i] = new JLabel();
      scrollPanes[i] = new JScrollPane(imageLabels[i]);
      imagePanel.add(scrollPanes[i]);
    }

    frame.getContentPane().add(imagePanel, BorderLayout.CENTER);
    frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    frame.setResizable(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }


  private void showPopupTextFieldForCompress() {
    JTextField textField = new JTextField(15);

    JPanel panel = new JPanel();
    panel.add(new JLabel("Enter the parameter for compression:"));
    panel.add(textField);

    int result = JOptionPane.showConfirmDialog(null, panel, "Popup TextField",
            JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      try {
        int userInput = Integer.parseInt(textField.getText());

        if (userInput >= 0 && userInput <= 100) {
          param_compress = userInput;
        } else {
          JOptionPane.showMessageDialog(null,
                  "Parameter for compression must be an integer between 0 and 100.",
                  "Error", JOptionPane.ERROR_MESSAGE);
        }
      } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null,
                "Invalid input. Please enter a valid integer.", "Error",
                JOptionPane.ERROR_MESSAGE);
      }
    }
  }


  private void showPopupTextFieldForLevels() {
    JTextField textField_B = new JTextField(15);
    JTextField textField_M = new JTextField(15);
    JTextField textField_W = new JTextField(15);

    JPanel panel = new JPanel();
    panel.add(new JLabel("Enter the parameters B, M, W one after another in that order:"));
    panel.add(textField_B);
    panel.add(textField_M);
    panel.add(textField_W);

    int result = JOptionPane.showConfirmDialog(null, panel, "Popup TextField",
            JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      try {
        int b = Integer.parseInt(textField_B.getText());
        int m = Integer.parseInt(textField_M.getText());
        int w = Integer.parseInt(textField_W.getText());

        if (b >= 0 && b <= 255 && m >= 0 && m <= 255 && w >= 0 && w <= 255 && b <= m && m <= w) {
          param_levels[0] = b;
          param_levels[1] = m;
          param_levels[2] = w;

        } else {
          JOptionPane.showMessageDialog(null,
                  "Parameters B, M, and W must be integers between 0 and 100 and in "
                          + "ascending order.", "Error", JOptionPane.ERROR_MESSAGE);
        }
      } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid input. Please enter "
                + "valid integers for B, M, and W.", "Error", JOptionPane.ERROR_MESSAGE);
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }
  }


  private void loadHelper() throws IOException {
    imageLoaded = true;
    isNotSaved = true;
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setCurrentDirectory(new File("./res/"));
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Images",
            "ppm", "jpg", "jpeg", "png");
    fileChooser.setFileFilter(filter);
    int returnValue = fileChooser.showOpenDialog(null);
    if (returnValue == JFileChooser.APPROVE_OPTION) {
      File selectedFile = fileChooser.getSelectedFile();
      String filePath = selectedFile.getCanonicalPath();
      stringInput = "load /" + filePath + " input";
    }
  }

  private String handleButtonClick(int buttonIndex) throws Exception {
    if (correctSplit) {
      stringInput = "";
      splitCommand = "";
      try {
        if (!imageLoaded && buttonIndex != 0) {
          throw new Exception("Please load an image first.");
        }
        {
          switch (buttonIndex) {
            case 0:
              if (isNotSaved) {
                Object[] options = {"I understand", "Cancel"};

                // Show the option dialog
                int result = JOptionPane.showOptionDialog(
                        null,
                        "The image is not saved, do you still wish to proceed",
                        "Load alert",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE,
                        null,
                        options,
                        options[1]);

                if (result == JOptionPane.YES_OPTION) {

                  loadHelper();
                } else {
                }

              } else {
                loadHelper();
              }
              break;
            case 1:
              isNotSaved = true;
              stringInput = "red-component input input";
              break;
            case 2:
              isNotSaved = true;
              stringInput = "green-component input input";
              break;
            case 3:
              isNotSaved = true;
              stringInput = "blue-component input input";
              break;
            case 4:
              isNotSaved = true;
              splitCommand = "value-component";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 5:
              isNotSaved = true;
              splitCommand = "intensity-component";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 6:
              isNotSaved = true;
              splitCommand = "luma-component";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 7:
              isNotSaved = true;
              splitCommand = "sepia";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 8:
              isNotSaved = true;
              splitCommand = "blur";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 9:
              isNotSaved = true;
              splitCommand = "sharpen";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 10:
              isNotSaved = true;
              stringInput = "horizontal-flip input input";
              break;
            case 11:
              isNotSaved = true;
              stringInput = "vertical-flip input input";
              break;
            case 12:
              isNotSaved = true;
              stringInput = "compress " + param_compress + " input input";
              break;
            case 13:
              isNotSaved = true;
              splitCommand = "color-correct";
              stringInput = splitCommand + " input input split " + splitParam;
              break;
            case 14:
              isNotSaved = true;
              splitCommand = "levels-adjust ";
              stringInput = splitCommand + param_levels[0] + " " + param_levels[1] + " " +
                      param_levels[2] + " input input split " + splitParam;
              break;

            case 15:
              // Histogram save
              JFileChooser saveFileChooser1 = new JFileChooser();
              saveFileChooser1.setCurrentDirectory(new File("./res/"));
              saveFileChooser1.setFileSelectionMode(JFileChooser.FILES_ONLY);

              JComboBox<String> fileTypeComboBox1 = new JComboBox<>(new String[]{"ppm", "png",
                      "jpg"});
              fileTypeComboBox1.setSelectedIndex(0);

              JPanel fileTypePanel1 = new JPanel();
              fileTypePanel1.setLayout(new BorderLayout());
              fileTypePanel1.add(new JLabel("Choose file type:"), BorderLayout.NORTH);
              fileTypePanel1.add(fileTypeComboBox1, BorderLayout.CENTER);

              int fileTypeResult1 = JOptionPane.showConfirmDialog(null,
                      fileTypePanel1, "Choose File Type", JOptionPane.OK_CANCEL_OPTION);

              if (fileTypeResult1 == JOptionPane.OK_OPTION) {
                int saveResult = saveFileChooser1.showSaveDialog(null);

                if (saveResult == JFileChooser.APPROVE_OPTION) {
                  File selectedFile = saveFileChooser1.getSelectedFile();
                  String fileName = selectedFile.getName();
                  String selectedFileType = (String) fileTypeComboBox1.getSelectedItem();


                  String folderPath = selectedFile.getAbsolutePath() + "." + selectedFileType;
                  stringInput = "save /" + folderPath + " histogramTemp";
                }
              }
              break;

            case 16:
              // Save operation

              JFileChooser saveFileChooser = new JFileChooser();
              saveFileChooser.setCurrentDirectory(new File("./res/"));
              saveFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

              JComboBox<String> fileTypeComboBox = new JComboBox<>(new String[]{"ppm", "png",
                      "jpg"});
              fileTypeComboBox.setSelectedIndex(0);

              JPanel fileTypePanel = new JPanel();
              fileTypePanel.setLayout(new BorderLayout());
              fileTypePanel.add(new JLabel("Choose file type:"), BorderLayout.NORTH);
              fileTypePanel.add(fileTypeComboBox, BorderLayout.CENTER);

              int fileTypeResult = JOptionPane.showConfirmDialog(null,
                      fileTypePanel, "Choose File Type", JOptionPane.OK_CANCEL_OPTION);

              if (fileTypeResult == JOptionPane.OK_OPTION) {
                int saveResult = saveFileChooser.showSaveDialog(null);

                if (saveResult == JFileChooser.APPROVE_OPTION) {
                  File selectedFile = saveFileChooser.getSelectedFile();
                  String selectedFileType = (String) fileTypeComboBox.getSelectedItem();
                  String folderPath = selectedFile.getAbsolutePath() + "." + selectedFileType;
                  stringInput = "save /" + folderPath + " input";
                  isNotSaved = false;
                }
              }
              break;
            default:
              break;
          }
        }
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
      }
    }
    return stringInput;

  }

  @Override
  public void displayImage(int[][][] imageData) {
    try {
      ImageIcon imageIcon = createImageIcon(imageData);
      imageLabels[3].setIcon(imageIcon);
      imageLabels[3].setToolTipText("Current Image");
      imagePanel.revalidate();
      imagePanel.repaint();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void displayErrorMessage(String errorMessage) {
    JOptionPane.showMessageDialog(null, errorMessage, "Error",
            JOptionPane.ERROR_MESSAGE);
  }

  @Override
  public void previousImage(int[][][] imageData) {
    try {
      ImageIcon imageIcon = createImageIcon(imageData);
      imageLabels[2].setIcon(imageIcon);
      imageLabels[2].setToolTipText("Previous Image");

      imagePanel.revalidate();
      imagePanel.repaint();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void displayHistogram(int[][][] imageData) {
    try {
      ImageIcon imageIcon = createImageIcon(imageData);
      imageLabels[1].setIcon(imageIcon);
      imageLabels[1].setPreferredSize(new Dimension(imageIcon.getIconWidth(),
              imageIcon.getIconHeight()));
      imageLabels[1].setToolTipText("Histogram of Current Image");
      imagePanel.revalidate();
      imagePanel.repaint();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public void loadedImage(int[][][] imageData) {
    try {
      ImageIcon imageIcon = createImageIcon(imageData);
      imageLabels[0].setIcon(imageIcon);
      imageLabels[0].setToolTipText("Loaded Image");
      imagePanel.revalidate();
      imagePanel.repaint();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private ImageIcon createImageIcon(int[][][] imageData) {
    int width = imageData.length;
    int height = imageData[0].length;
    BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
        int rgb = (imageData[x][y][0] << 16) | (imageData[x][y][1] << 8) | imageData[x][y][2];
        bufferedImage.setRGB(x, y, rgb);
      }
    }
    return new ImageIcon(bufferedImage);
  }
}
