package controller;

import view.ImageView;

/**
 * The GUIImageControllerInterface defines the controller handling GUI interactions related to
 * image processing. It takes in inputs from the view and sends it to controller for further
 * processing and functions.
 */
public interface GUIImageControllerInterface {

  /**
   * Handles a user action triggered by a GUI component.
   *
   * @param input The input representing the user action.
   * @throws Exception If an error occurs while processing the user action.
   */
  void handleClick(String input) throws Exception;

  /**
   * Sets the associated view for the controller. The view is responsible for displaying
   * information to the user.
   *
   * @param view The ImageView instance to be associated with the controller.
   */
  void setView(ImageView view);
}
