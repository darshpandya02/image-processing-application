package controller;

import java.util.Arrays;

import model.ImageModel;
import view.ImageView;

public class GUIController implements GUIImageControllerInterface {

  private static ImageView view;
  private static ImageModel model;
  private ImageController controller = new ImageController(model, view);

  public GUIController(ImageModel model) {
    this.model = model;
  }

  // Setter method to set the view after its creation
  public void setView(ImageView view) {
    this.view = view;
  }

  public void handleClick(String input) throws Exception {
    try {
      String[] partInFile = input.split(" ");
      String command1 = partInFile[0];
      System.out.println(Arrays.toString(partInFile));
      controller.switchCaseHelper(command1, partInFile);
      System.out.println(Arrays.toString(partInFile));
      if(partInFile.length<5){controller.displayImageInFrame(partInFile[2]);}
      else{controller.displayImageInFrame(partInFile[partInFile.length-3]);}
    } catch (Exception e) {
      // Display an error message in the GUI
      view.displayErrorMessage("Error: " + e.getMessage());
    }

  }

  public int[][][] displayPreview(String inp, int param) throws Exception {
    String[] parts = inp.split(" ");
    String[] updatedParts = new String[parts.length];
    System.arraycopy(parts, 0, updatedParts, 0, parts.length);
    updatedParts[parts.length-1] = String.valueOf(param);
    updatedParts[parts.length-3] = "tempImage";
    controller.switchCaseHelper(updatedParts[0], updatedParts);

    return controller.getHashMapFromModel("tempImage");
  }

}
